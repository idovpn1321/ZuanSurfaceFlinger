# KernelSU SurfaceFlinger Guard Module

Modul KernelSU ini menyatukan:
- SurfaceFlinger tuning dengan uclamp
- Validasi suhu thermal zone (menghindari sensor error)
- Tuning hanya aktif saat suhu aman

Dibuat oleh: **ZuanPrjkt**