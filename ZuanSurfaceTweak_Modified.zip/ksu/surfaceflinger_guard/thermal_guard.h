#ifndef THERMAL_GUARD_H
#define THERMAL_GUARD_H

void thermal_guard_init(void);
int get_valid_temperature(void);

#endif // THERMAL_GUARD_H