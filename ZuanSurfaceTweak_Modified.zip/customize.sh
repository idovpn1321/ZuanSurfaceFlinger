SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=true
LATESTARTSERVICE=false

# Custom print banner with sarcasm & device info
. $MODPATH/custom_print.sh

# Auto-fix permission
chmod 0755 "$0"